import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { TechnicianService } from '../../../services/technician.service';
import { Technician } from '../../../models/technician.model';
import { ServiceAssignment } from '../../../models/assignment.model';
import { FormatStatusPipe } from '../../../pipes/format-status-pipe';
import { CommonService } from '../../../common-service';

@Component({
  selector: 'app-technician-assignment',
  standalone: true,
  imports: [CommonModule, FormsModule, FormatStatusPipe],
  templateUrl: './technician-assignment.html',
  styleUrls: ['./technician-assignment.css'],
})
export class TechnicianAssignmentComponent implements OnInit {
  currentView: 'addTechnician' | 'assignTask' | 'showList' = 'addTechnician';
  technicians: Technician[] = [];
  availableTechnicians: Technician[] = [];
  assignments: ServiceAssignment[] = [];
  commonTechnicians: { name: string; expertise: string; available: boolean }[] = [];
  isTaskConfirmed: boolean = false;

  skills: Technician['skill'][] = [
    'Engine Servicing',
    'Brake Repair',
    'Full Inspection',
    'Suspension Upgrade',
    'Tyre Replacement',
  ];
  statuses: ServiceAssignment['status'][] = ['Assigned', 'Work In Progress', 'Completed'];

  newTechnician: Partial<Technician> = {};
  newAssignment: Partial<ServiceAssignment> = {};

  constructor(private techService: TechnicianService, private commonService: CommonService) {}
  scheduledServices: any[] = [];
  selectedTechnicianName: string = '';

  ngOnInit(): void {
    this.refreshData();
    this.resetNewTechnician();
    this.resetNewAssignment();
    this.commonTechnicians = this.commonService.getRegisteredTechnicians();
    this.scheduledServices = this.commonService.getScheduledServices(); // ✅ Load services
  }

  refreshData(): void {
    this.technicians = this.techService.getTechnicians();
    this.availableTechnicians = this.technicians.filter((t) => t.availability === 'Available');
    this.techService.assignments$.subscribe((data) => {
      this.assignments = data;
    });
  }

  showView(view: 'addTechnician' | 'assignTask' | 'showList'): void {
    this.currentView = view;
  }

  resetNewTechnician(): void {
    this.newTechnician = {
      technicianId: undefined,
      name: '',
      skill: this.skills[0],
      availability: 'Available',
    };
  }

  resetNewAssignment(): void {
    this.newAssignment = {
      assignmentId: undefined,
      serviceId: undefined,
      technicianId: undefined,
      status: this.statuses[0],
    };
  }

  onAddTechnician(form: NgForm): void {
    if (form.invalid) return;
    try {
      const id = Number(this.newTechnician.technicianId);
      if (!id || id <= 0) throw new Error('Technician ID must be a positive number.');

      const payload: Technician = {
        technicianId: id,
        name: String(this.newTechnician.name).trim(),
        skill: this.newTechnician.skill!,
        availability: this.newTechnician.availability!,
      };

      this.techService.addTechnician(payload);

      const simplified = {
        name: payload.name,
        expertise: payload.skill,
        available: payload.availability === 'Available',
      };
      this.commonService.RegisterTechnicians(simplified);

      this.commonTechnicians = this.commonService.getRegisteredTechnicians(); // ✅ Refresh dropdown

      alert('Technician added successfully!');
      this.refreshData();
      form.resetForm();
      this.resetNewTechnician();
    } catch (e: any) {
      alert(`Error: ${e.message}`);
    }
  }

  onAssignTask(form: NgForm): void {
    if (form.invalid || !this.isTaskConfirmed) return;
    try {
      const matchedTech = this.technicians.find((t) => t.name === this.selectedTechnicianName);
      if (!matchedTech) throw new Error('Selected technician not found.');

      const payload: ServiceAssignment = {
        assignmentId: Number(this.newAssignment.assignmentId),
        serviceId: Number(this.newAssignment.serviceId),
        technicianId: matchedTech.technicianId,
        status: 'Assigned',
      };

      this.techService.assignTask(payload);
      alert('Task assigned successfully!');
      this.refreshData();
      form.resetForm();
      this.resetNewAssignment();
      this.isTaskConfirmed = false;
    } catch (e: any) {
      alert(`Error: ${e.message}`);
    }
  }

  updateStatus(assignmentId: number, newStatus: ServiceAssignment['status']): void {
    try {
      this.techService.updateAssignmentStatus(assignmentId, newStatus);
      this.refreshData();
      alert(`Status for assignment ${assignmentId} updated.`);
    } catch (e: any) {
      alert(`Error: ${e.message}`);
    }
  }

  getTechnicianName(id: number): string {
    const tech = this.technicians.find((t) => t.technicianId === id);
    return tech ? tech.name : 'Unknown';
  }

  onServiceIdChange(): void {
    const selectedId = this.newAssignment.serviceId;
    const service = this.scheduledServices.find((s) => s.serviceId === selectedId);
    this.selectedTechnicianName = service?.technician || '';
  }
}
