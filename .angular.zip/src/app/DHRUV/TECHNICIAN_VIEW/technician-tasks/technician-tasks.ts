import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TechnicianService } from '../../../services/technician.service';
import { ServiceAssignment } from '../../../models/assignment.model';
import { FormatStatusPipe } from '../../../pipes/format-status-pipe';

@Component({
  selector: 'app-technician-tasks',
  standalone: true,
  imports: [CommonModule, FormatStatusPipe],
  templateUrl: './technician-tasks.html',
  styleUrls: ['./technician-tasks.css']
})
export class TechnicianTasksComponent implements OnInit {
  assignments: ServiceAssignment[] = [];

  constructor(private techService: TechnicianService) {}

  ngOnInit(): void {
    this.techService.assignments$.subscribe(data => {
      this.assignments = data;
    });
  }

  getTechnicianName(id: number): string {
    return this.techService.getTechnicianName(id);
  }

  updateStatus(assignmentId: number, newStatus: ServiceAssignment['status']): void {
    try {
      this.techService.updateAssignmentStatus(assignmentId, newStatus);
    } catch (e: any) {
      alert(`Error: ${e.message}`);
    }
  }
}
