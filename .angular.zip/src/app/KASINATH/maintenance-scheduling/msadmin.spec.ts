import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MSAdmin } from './msadmin';

describe('MSAdmin', () => {
  let component: MSAdmin;
  let fixture: ComponentFixture<MSAdmin>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MSAdmin]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MSAdmin);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
