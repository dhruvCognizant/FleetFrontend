import { Component } from '@angular/core';
import { LandingHeader } from '../landing-header/landing-header';
import { FooterComponent } from '../../footer/footer';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-landing-page',
  standalone: true,
  imports: [ RouterModule, LandingHeader, FooterComponent ],
  templateUrl: './landing-page.html',
  styleUrls: ['./landing-page.css']
})
export class LandingPageComponent {}
