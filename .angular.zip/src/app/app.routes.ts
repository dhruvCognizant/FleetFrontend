import { Routes } from '@angular/router';
import { LandingPageComponent } from './LandingPage/landing-page/landing-page.js';

export const routes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  // { path: 'schedule', component: Kbody },
  // { path: 'vehicles', component: Content },
  // { path: 'history', component: UserAdmin },
  // { path: 'dashboard', component: Dashboard },
  // { path: 'technician', component: TechnicianAssignmentComponent },
];
