import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommonService } from './common-service';
import { HeaderComponent } from './header/header';
import { FooterComponent } from './footer/footer';
import { TechnicianAssignmentComponent } from './DHRUV/ADMIN_VIEW/technician-assignment/technician-assignment';
import { TechnicianTasksComponent } from './DHRUV/TECHNICIAN_VIEW/technician-tasks/technician-tasks';
import { UserAssignmentsComponent } from './DHRUV/USER_VIEW/user-assignments/user-assignments';
import { LoginComponent } from './Login/login';
import { Content } from './ISHAN/content/content';
import { ServiceSchedulingComponent } from './KASINATH/maintenance-scheduling/msadmin';
import { UserAdmin } from "./HARSHIT/service-history/user-admin";
// import { ServiceSchedulingComponent } from './KASINATH/maintenance-scheduling/msadmin';
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    HeaderComponent,
    FooterComponent,
    TechnicianAssignmentComponent,
    TechnicianTasksComponent,
    UserAssignmentsComponent,
    LoginComponent,
    Content,
    ServiceSchedulingComponent,
    UserAdmin
],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class AppComponent {
  constructor(public commonService: CommonService) {}
 
  get role(): 'admin' | 'technician' | 'user' | null {
    return this.commonService.getRole();
  }
}