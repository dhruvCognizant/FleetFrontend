import { Injectable } from '@angular/core';
import { NewVehicle } from './ISHAN/interface/IVehicle';

interface Credential {
  email: string;
  password: string;
}

enum ServiceCode {
  'Oil Change' = 'FC01',
  'Brake Check' = 'FC02',
  'Battery Test' = 'FC03'
}

@Injectable({ providedIn: 'root' })
export class CommonService {
  private adminUsername = 'admin@admin.com';
  private adminPassword = 'admin123';

  private users: Credential[] = [
    { email: 'user@gmail.com', password: 'user123' },
    { email: 'harshith@gmail.com', password: 'harshith123' },
    { email: 'kasi@gmail.com', password: 'kasi123' },
    { email: 'krishna@gmail.com', password: 'krishna123' }
  ];

  private technicians: Credential[] = [
    { email: 'tech@fleet.com', password: 'tech123' },
    { email: 'john@fleet.com', password: 'john123' }
  ];

  private role: 'admin' | 'technician' | 'user' | null = null;
  private loggedInEmail: string | null = null;

  vehicleListChanged = false;

  private registeredVehicles: NewVehicle[] = [
    {
      vehicleId: 'V001',
      type: 'SUV',
      Make: 'Toyota',
      model: 'Fortuner',
      year: 2025,
      vin: 'ABC123XYZ',
      lastService: '2025-01-15'
    }
  ];

  private scheduledServices: any[] = [];

  private registeredTechnicians = [
    { name: 'Technician A', expertise: 'Engine & Transmission', available: true },
    { name: 'Technician B', expertise: 'Electrical Systems', available: true },
    { name: 'Technician C', expertise: 'Brakes & Suspension', available: true },
    { name: 'Technician D', expertise: 'General Maintenance', available: true },
    { name: 'Technician E', expertise: 'Diagnostics', available: true }
  ];

  login(email: string, password: string): boolean {
    if (email === this.adminUsername && password === this.adminPassword) {
      this.role = 'admin';
      this.loggedInEmail = email;
      return true;
    } else if (this.technicians.find(t => t.email === email && t.password === password)) {
      this.role = 'technician';
      this.loggedInEmail = email;
      return true;
    } else if (this.users.find(u => u.email === email && u.password === password)) {
      this.role = 'user';
      this.loggedInEmail = email;
      return true;
    }
    return false;
  }

  getRole(): 'admin' | 'technician' | 'user' | null {
    return this.role;
  }

  getEmail(): string | null {
    return this.loggedInEmail;
  }

  logout(): void {
    this.role = null;
    this.loggedInEmail = null;
  }

  addVehicle(vehicle: NewVehicle): void {
    this.registeredVehicles.push(vehicle);
    this.vehicleListChanged = true;
  }

  getRegisteredVehicles(): NewVehicle[] {
    return this.registeredVehicles;
  }

  getAvailableVehicles(): NewVehicle[] {
    const scheduledIds = this.scheduledServices.map(s => s.vehicleId.toLowerCase());
    return this.registeredVehicles.filter(v => !scheduledIds.includes(v.vehicleId.toLowerCase()));
  }

  getRegisteredTechnicians(): any[] {
    return this.registeredTechnicians.filter(t => t.available);
  }

  RegisterTechnicians(technician: { name: string; expertise: string; available: boolean }): void {
    this.registeredTechnicians.push(technician);
  }

getScheduledServices(): any[] {
  console.log('Scheduled services:', this.scheduledServices);
  return this.scheduledServices;
}


  addScheduledService(service: any): void {
    this.scheduledServices.push(service);
    this.markTechnicianUnavailable(service.technician);
  }

  private markTechnicianUnavailable(name: string): void {
    const tech = this.registeredTechnicians.find(t => t.name === name);
    if (tech) tech.available = false;
  }

  generateServiceId(serviceType: string): string {
    const prefix = ServiceCode[serviceType as keyof typeof ServiceCode] || 'FC00';
    const randomNumber = Math.floor(1000 + Math.random() * 9000);
    return `${prefix}-${randomNumber}`;
  }
}
