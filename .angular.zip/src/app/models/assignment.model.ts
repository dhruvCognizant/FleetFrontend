export interface ServiceAssignment {
    assignmentId: number;
    serviceId: number;
    technicianId: number;
    status: 'Assigned' | 'Work In Progress' | 'Completed';
}