export interface Technician {
    technicianId: number;
    name: string;
    skill: 'Engine Servicing' | 'Brake Repair' | 'Full Inspection' | 'Suspension Upgrade' | 'Tyre Replacement';
    availability: 'Available' | 'Not Available';
}