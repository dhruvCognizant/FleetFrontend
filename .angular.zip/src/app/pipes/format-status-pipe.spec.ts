import { FormatStatusPipe } from './format-status-pipe';

describe('FormatStatusPipe', () => {
  it('create an instance', () => {
    const pipe = new FormatStatusPipe();
    expect(pipe).toBeTruthy();
  });
});
