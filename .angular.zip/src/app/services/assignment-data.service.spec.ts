import { TestBed } from '@angular/core/testing';

import { AssignmentData } from './assignment-data.service';

describe('AssignmentData', () => {
  let service: AssignmentData;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AssignmentData);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
