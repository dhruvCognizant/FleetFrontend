import { Injectable } from '@angular/core';
import { TechnicianService } from './technician.service';
import { Observable } from 'rxjs';
import { ServiceAssignment } from '../models/assignment.model';

@Injectable({ providedIn: 'root' })
export class AssignmentDataService {
  constructor(private technicianService: TechnicianService) {}

  getAllAssignments(): Observable<ServiceAssignment[]> {
    return this.technicianService.assignments$;
  }

  getTechnicianName(id: number): string {
    return this.technicianService.getTechnicianName(id);
  }
}
