import { Injectable } from '@angular/core';
import { Technician } from '../models/technician.model';
import { ServiceAssignment } from '../models/assignment.model';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TechnicianService {
  private technicians: Technician[] = [];
  private assignments: ServiceAssignment[] = [];

  private assignmentsSubject = new BehaviorSubject<ServiceAssignment[]>([]);
  assignments$: Observable<ServiceAssignment[]> = this.assignmentsSubject.asObservable();

  constructor() {}

  getTechnicians(): Technician[] {
    return this.technicians.map(t => ({ ...t }));
  }

  addTechnician(technician: Technician): Technician {
    const id = Number(technician.technicianId);
    if (!Number.isFinite(id) || id <= 0) {
      throw new Error('Technician ID must be a positive number.');
    }
    const isIdUnique = !this.technicians.some(t => t.technicianId === id);
    if (!isIdUnique) {
      throw new Error('Technician ID must be unique.');
    }
    const toAdd = { ...technician, technicianId: id };
    this.technicians.push(toAdd);
    return { ...toAdd };
  }

  getAssignments(): ServiceAssignment[] {
    return this.assignments.map(a => ({ ...a }));
  }

  getTechnicianName(id: number): string {
    const tech = this.technicians.find(t => t.technicianId === id);
    return tech ? tech.name : 'Unknown';
  }

  assignTask(assignment: ServiceAssignment): ServiceAssignment {
    const assignmentId = Number(assignment.assignmentId);
    const serviceId = Number(assignment.serviceId);
    const technicianId = Number(assignment.technicianId);

    if (!Number.isFinite(assignmentId) || assignmentId <= 0) {
      throw new Error('Assignment ID must be a positive number.');
    }
    if (!Number.isFinite(serviceId) || serviceId <= 0) {
      throw new Error('Service ID must be a positive number.');
    }
    if (!Number.isFinite(technicianId) || technicianId <= 0) {
      throw new Error('Technician ID must be a positive number.');
    }

    const isIdUnique = !this.assignments.some(a => a.assignmentId === assignmentId);
    if (!isIdUnique) {
      throw new Error('Assignment ID must be unique.');
    }

    const toAdd: ServiceAssignment = {
      assignmentId,
      serviceId,
      technicianId,
      status: assignment.status
    };
    this.assignments.push(toAdd);
    this.assignmentsSubject.next([...this.assignments]); // 🔥 Notify subscribers
    return { ...toAdd };
  }

  updateAssignmentStatus(assignmentId: number, newStatus: ServiceAssignment['status']): ServiceAssignment {
    const assignment = this.assignments.find(a => a.assignmentId === assignmentId);
    if (!assignment) {
      throw new Error('Assignment not found.');
    }
    assignment.status = newStatus;
    this.assignmentsSubject.next([...this.assignments]); // 🔥 Notify subscribers
    return { ...assignment };
  }
}
